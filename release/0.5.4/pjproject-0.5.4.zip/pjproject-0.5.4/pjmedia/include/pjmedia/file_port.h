/* $Id: file_port.h 222 2006-02-23 02:09:10Z bennylp $ */
/* 
 * Copyright (C) 2003-2006 Benny Prijono <benny@prijono.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
#ifndef __PJMEDIA_FILE_PORT_H__
#define __PJMEDIA_FILE_PORT_H__

/**
 * @file file_port.h
 * @brief File player and recorder.
 */
#include <pjmedia/port.h>


PJ_BEGIN_DECL


/**
 * Create file player port.
 */
PJ_DECL(pj_status_t) pjmedia_file_player_port_create( pj_pool_t *pool,
						      const char *filename,
						      unsigned flags,
						      pj_ssize_t buff_size,
						      void *user_data,
						      pjmedia_port **p_port );



PJ_END_DECL


#endif	/* __PJMEDIA_FILE_PORT_H__ */
