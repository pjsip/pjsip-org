#ifndef __SPEEX_TYPES_H__
#define __SPEEX_TYPES_H__

#include <pj/types.h>

typedef pj_int16_t  spx_int16_t;
typedef pj_uint16_t spx_uint16_t;
typedef pj_int32_t  spx_int32_t;
typedef pj_uint32_t spx_uint32_t;

#endif


